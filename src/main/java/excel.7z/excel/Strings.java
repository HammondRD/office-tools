package excel;

public class Strings {
	protected static String FRAME_TITLE="Работа с данными";
	protected static String BTN_OPEN_FILE = "Загрузить данные";
}
