package excel;

public class Globals {
	protected static Object[][] tableData;
	protected static Integer columnWidths = 100;
	protected static ExcelManager excel;
	protected static int lastRowNum;
	protected static int lastColNum;
	protected static int cellRC;
	protected static String cellValue;
}
